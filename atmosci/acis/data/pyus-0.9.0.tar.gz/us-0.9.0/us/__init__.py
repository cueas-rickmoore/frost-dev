from . import states
from .states import (
	STATES, STATES_CONTIGUOUS, STATES_CONTINENTAL,
	TERRITORIES, STATES_AND_TERRITORIES, OBSOLETE
)
from .unitedstatesofamerica import *

__appname__ = 'us'
__version__ = '0.9.0'
