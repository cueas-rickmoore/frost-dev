name = 'United States of America'
abbr = 'US'
